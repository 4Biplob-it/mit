<?php

/*
Plugin Name: Mit Custom Post
Description: Common Custom Post Types For Mit Theme
Plugin URI: https://github.com/4Biplob-it/mit/archive/refs/heads/main.zip
Author: Mizanur it
Author URI: https://www.mizanurit.com
Text Domain: mit
*/ 

// Custom Posts
function mit_custom_posts(){

    // Slider Custom Post
    register_post_type('sliders', array(
        'labels' => array(
            'name' => __('Slides', 'mit'),
            'singular_name' => __('Slider', 'mit'),
            'add_new' => __('Add New Slide', 'mit'),
            'add_new_item' => __('Add New Slide', 'mit'),
            'featured_image' => __('Slider Image', 'mit'),
            'set_featured_image' => __('Set Slider Image', 'mit'),
            'search_items' => __('Search Slide', 'mit'),
            'edit_item' => __('Edit Slide', 'mit')
        ),
        'menu_icon' => 'dashicons-images-alt2',
        'public' => true,
        'supports' => array('title', 'editor', 'thumbnail', 'custom-fields')
    ));

    // Services Custom Post
    register_post_type('services', array(
        'labels' => array(
            'name' => __('Services', 'mit'),
            'singular_name' => __('Service', 'mit'),
            'add_new' => __('Add New Service', 'mit'),
            'add_new_item' => __('Add New Service', 'mit'),
            'search_items' => __('Search Service', 'mit'),
            'edit_item' => __('Edit Service', 'mit')
        ),
        'menu_icon' => 'dashicons-screenoptions',
        'public' => true,
        'supports' => array('title', 'editor', 'custom-fields')
    ));

    // Team Custom Post
    register_post_type('team', array(
        'labels' => array(
            'name' => __('Team', 'mit'),
            'singular_name' => __('team', 'mit'),
            'add_new' => __('Add New Team', 'mit'),
            'add_new_item' => __('Add New Team', 'mit'),
            'featured_image' => __('Team Image', 'mit'),
            'set_featured_image' => __('Set Team Image', 'mit'),
            'search_items' => __('Search Team', 'mit'),
            'edit_item' => __('Edit Team', 'mit')
        ),
        'menu_icon' => 'dashicons-groups',
        'public' => true,
        'supports' => array('title', 'editor','thumbnail', 'custom-fields', 'page-attributes')

    ));

    // Testimonials Custom Post
    register_post_type('testimonials', array(
        'labels' => array(
            'name' => __('Testimonials', 'mit'),
            'singular_name' => __('Testimonial', 'mit'),
            'add_new' => __('Add New Testimonial', 'mit'),
            'add_new_item' => __('Add New Testimonial', 'mit'),
            'featured_image' => __('Testimonial Image', 'mit'),
            'set_featured_image' => __('Set Testimonial Image', 'mit'),
            'search_items' => __('Search Testimonial', 'mit'),
            'edit_item' => __('Edit Testimonial', 'mit')
        ),
        'menu_icon' => 'dashicons-groups',
        'public' => true,
        'supports' => array('thumbnail', 'custom-fields', 'page-attributes')
    ));

    // Gallery Custom Post
    register_post_type('gallery', array(
        'labels' => array(
            'name' => __('Gallery', 'mit'),
            'singular_name' => __('Gallery', 'mit'),
            'add_new' => __('Add New Gallery', 'mit'),
            'add_new_item' => __('Add New Gallery', 'mit'),
            'featured_image' => __('Gallery Image', 'mit'),
            'set_featured_image' => __('Set Gallery Image', 'mit'),
            'search_items' => __('Search Gallery', 'mit'),
            'edit_item' => __('Edit Gallery', 'mit')
        ),
        'menu_icon' => 'dashicons-groups',
        'public' => true,
        'supports' => array('title','custom-fields', 'page-attributes')
    ));

    // Portfolio Custom Post
    register_post_type('portfolio', array(
        'labels' => array(
            'name' => __('Portfolio', 'mit'),
            'singular_name' => __('Portfolio', 'mit'),
            'add_new' => __('Add New Portfolio', 'mit'),
            'add_new_item' => __('Add New Portfolio', 'mit'),
            'featured_image' => __('Portfolio Image', 'mit'),
            'set_featured_image' => __('Set Portfolio Image', 'mit'),
            'search_items' => __('Search Portfolio', 'mit'),
            'edit_item' => __('Edit Portfolio', 'mit')
        ),
        'menu_icon' => 'dashicons-groups',
        'public' => true,
        'supports' => array('title','editor','thumbnail', 'custom-fields', 'page-attributes')
    ));

    // Portfolio Taxonomy
    register_taxonomy('portfolio-cat', 'portfolio', array(
        'labels' => array(
            'name' => __('Categories', 'mit'),
            'singular_name' => __('Category', 'mit')
        ),
        'hierarchical' => true,
        'show_admin_column' => true
    ));



}
add_action('init', 'mit_custom_posts');

